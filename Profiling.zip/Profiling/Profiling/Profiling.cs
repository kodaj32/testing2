﻿//=================================================================================//
//Názov projektu: IVS projekt č.2
//Súbor: Profiling.cs
//Dátum: 30.3.2021
//Posledná zmena: 19.4.2021
//Autor: Radoslav Kodaj (xkodaj00@stud.fit.vutbr.cz)
//
//Popis: Výpočet výberovej smerodajnej odchylky s použitím matematickej knižnice
//
//=================================================================================//
/**
 * @file Profiling.cs
 * 
 * @brief Výpočet výberovej smerodajnej odchylky
 * @author Radoslav Kodaj (xkodaj00)
 * 
 */

using System;
using MathLib;

namespace Profiling
{
    class Profiling
    {
        static void Main(string[] args)
        {
            string numstring = null;
            char[] delimChars = { ' ', '\t', '\n' };
            string line = Console.ReadLine();
            numstring += line;
            while ((line = Console.ReadLine()) != string.Empty)
            {
                numstring += " " + line;
            }

            string[] words = numstring.Split(delimChars);
            double[] numbers = new double[words.Length];
            int i = 0;
            foreach(var word in words)
            {
                numbers[i] = (Convert.ToDouble(word));
                i++;
            }

            double result = sample_standart_deviation(numbers); 

            Console.Write(result);
            Console.Read();
        }

        /**
         * Funkcia pre výpočet výberovej smerodajnej odchýlky
         * 
         * @param nums Pole hodnôt pre výpočet oschylky
         * @rerturn Vracia výsledok výpočtu výberovej smerodajnej odhcýlky
         */
        static double sample_standart_deviation (double[] nums)
        {
            double result_s;
            int N = nums.Length;
            double avg;
            double x_sum;

            avg = average(nums);

            for (int i = 0; i < nums.Length; i++)
            {
                nums[i] = nums[i] - avg;
            }

            x_sum = suma(nums, 2);

            result_s = MLib.div(1, N - 1);
            result_s = MLib.mul(result_s, x_sum);
            result_s = MLib.sqrt(result_s, 2);

            return result_s;
        }

        /**
         * Funkcia prer výpočet sumy 
         * 
         * @param nums Pole hodnôt ktoré sa majú sčítať
         * @param exp Exponent na ktore maju byť jednotlivé čísla umocnené
         * @return Vracia súčet všetkých hodnôt z pola umocnené na exponent
         */
        static double suma(double[] nums, int exp)
        {
            double sum_result = 0;

            for (int i = 0; i < nums.Length; i++)
            {
                sum_result = MLib.add(sum_result, MLib.pow(nums[i], exp));
            }

            return sum_result;
        }

        /**
         * Funkcia pre výpočet aritmetického priemeru
         * 
         * @param nums Pole hodnôt z ktorých sa má aritmetický priemer vypočítať
         * @return Vracia aritmetický priemer vypočítaný z pola hodnôt
         */
        static double average(double[] nums)
        {
            double avg_result;
            avg_result = suma(nums, 1);
            avg_result = MLib.div(avg_result, nums.Length);

            return avg_result;
        }
    }
}

/*** Koniec súboru Profiling.cs ***/
